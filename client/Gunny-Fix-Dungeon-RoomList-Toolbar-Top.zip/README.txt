GUNNY - MOVE DUNGEON ROOM SEARCH BAR TO TOP

UI coordinates (320x240 logic pixels, automatically scaled by s):
DungeonScreen.java:
- SEARCH_Y: 153 -> 33 (search, join, refresh, online count)
- FIRST_ROW: 34 -> 49 (all 8 list slots moved below toolbar)
OnlineRooms.java:
- expedition room code input field Y: 152 -> 33

How to install:
1. BACK UP your existing client/src/DungeonScreen.java and client/src/OnlineRooms.java.
2. Since this ZIP is based on earlier src(3).zip, the SAFEST approach if you have continued editing these files is to apply the 3 replacements shown in the .patch instead of overwriting with these source files.
3. If neither file has changed since src(3).zip, copy the included src/*.java to client/src/.
4. Rebuild both E72 and E6 and verify mouse + keypad focus, especially the code input field and last row.

Changes are presentation-only; TCP/network protocol and room state are untouched.
Not emulator-tested.

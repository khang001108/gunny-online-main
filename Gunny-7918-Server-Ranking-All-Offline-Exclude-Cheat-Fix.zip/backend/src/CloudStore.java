import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.security.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Only this server knows the service role key. The MIDlet never receives it. */
class CloudStore {
    static final class Profile {
        String id,name;int stones;boolean dungeonClear;final int[] forgeLevels=new int[130];int experience;int shoppingMoney,wornMask=3;int publicId,gender,skin,coins=0,wins,owned=1,equipped;int[] bagLayout=new int[175];boolean characterChosen,custom;int[] look=new int[5];int[] wardrobe={1,1,1,1,1,1,1,1,1,1,1,1};
        final int[] forgeProgress=new int[130],craftStones=new int[4];
        int giftLevel=1,giftBags,vipTickets;long vipUntil;int luckyCharms,protectionCharms,wings,vipSpears;boolean wingEquipped,testCheats,testGod;
        int maxDamage;final int[] weaponUses=new int[10];int vipExp,wingOwned,equippedWing=-1;final int[] vipCards=new int[13];
        Profile(String id,String name){this.id=id;this.name=name;Arrays.fill(bagLayout,-1);}
    }
    static final class Login {String userId;int lifetime=3600;Login(String id){userId=id;}}
    final String url,key,service;
    final HttpClient http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(12)).followRedirects(HttpClient.Redirect.NEVER).build();
    CloudStore(){this(env("SUPABASE_URL"),env("SUPABASE_PUBLISHABLE_KEY").isEmpty()?env("SUPABASE_ANON_KEY"):env("SUPABASE_PUBLISHABLE_KEY"),env("SUPABASE_SECRET_KEY").isEmpty()?env("SUPABASE_SERVICE_ROLE_KEY"):env("SUPABASE_SECRET_KEY"),false);}
    CloudStore(String address,String publicKey,String privateKey,boolean testLoopback){url=address.replaceAll("/+$","");key=publicKey;service=privateKey;boolean local=testLoopback&&(url.startsWith("http://127.0.0.1:")||url.startsWith("http://localhost:"));if((!url.startsWith("https://")&&!local)||key.isEmpty()||service.isEmpty())throw new IllegalStateException("Configure SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY and SUPABASE_SECRET_KEY");}
    CloudStore(boolean test){url=key=service="";}
    static String env(String key){String v=System.getenv(key);return v==null?"":v.trim();}
    Object request(String path,String method,String body,boolean admin)throws Exception {
        HttpRequest.Builder b=HttpRequest.newBuilder(URI.create(url+path)).timeout(Duration.ofSeconds(20)).header("apikey",admin?service:key).header("Content-Type","application/json");
        if(admin&&!service.startsWith("sb_secret_"))b.header("Authorization","Bearer "+service);
        HttpResponse<String> r=http.send(b.method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofString(body)).build(),HttpResponse.BodyHandlers.ofString());
        if(r.statusCode()<200||r.statusCode()>=300){String detail=r.body();if(detail.contains("Too many overlapping announcements"))throw new IllegalArgumentException("Đã có 20 thông báo trùng thời gian. Dừng bớt hoặc chọn lịch khác.");if(path.startsWith("/rest/v1/rpc/")){String rpc=path.substring(path.lastIndexOf('/')+1),code="UNKNOWN";try{String parsed=Json.str(Json.obj(Json.parse(detail)),"code");if(parsed.matches("[A-Z0-9]{5,8}"))code=parsed;}catch(Exception ignored){}System.err.println("Supabase RPC "+rpc+" HTTP "+r.statusCode()+" code "+code);if(code.equals("22P02")&&rpc.equals("gunny_admin"))throw new IllegalArgumentException("Supabase không đọc được định dạng dữ liệu quản trị (22P02).");if(code.equals("PGRST202"))throw new IllegalStateException("Supabase chưa nhận API "+rpc+" (PGRST202). Kiểm tra cache, quyền service_role và migration.");if(code.equals("P0002"))throw new IllegalStateException("Không tìm thấy hồ sơ khi gọi "+rpc+" (P0002). Hãy đăng nhập lại; nếu còn lỗi, kiểm tra dữ liệu hồ sơ.");if(code.equals("42501"))throw new IllegalStateException("API "+rpc+" bị từ chối quyền (42501). Kiểm tra quyền service_role trên Supabase.");if(code.equals("42883"))throw new IllegalStateException("API "+rpc+" gọi hàm không tồn tại (42883). Kiểm tra định nghĩa hàm trong Supabase.");if(r.statusCode()==404)throw new IllegalStateException("Supabase trả lỗi khi gọi "+rpc+" (HTTP 404, "+code+"). Cần kiểm tra mã lỗi này trong Render Logs.");}if((detail.contains("PGRST204")||detail.contains("42703"))&&detail.contains("character_chosen"))throw new IllegalStateException("Chạy migration nhân vật 7.2.0 trên Supabase trước.");if(detail.contains("PGRST202")&&(detail.contains("gunny_equip")||detail.contains("gunny_exchange"))||detail.contains("42703")&&(detail.contains("shopping_money")||detail.contains("worn_mask")))throw new IllegalStateException("Chạy migration trang bị 7.1.8 trên Supabase trước.");if(detail.contains("gunny_profiles_name_unique"))throw new IllegalArgumentException("Tên nhân vật đã được sử dụng. Hãy chọn tên khác.");if(detail.contains("Gift exceeds wallet limit"))throw new IllegalArgumentException("Quà làm số dư vượt 999.999. Giảm quà rồi thử lại.");if(path.endsWith("gunny_support_admin")&&detail.contains("Account not found"))throw new IllegalArgumentException("Tài khoản nhận quà không còn tồn tại.");if(detail.contains("Insufficient stones"))throw new IllegalArgumentException("Chưa đủ đá cường hóa.");if(detail.contains("Insufficient shopping money or stone limit"))throw new IllegalArgumentException("Chưa đủ tiền mua sắm hoặc đã đạt giới hạn đá.");if(detail.contains("Forge level changed"))throw new IllegalArgumentException("Cấp rèn đã thay đổi. Mở lại Tiệm rèn để tải cấp mới.");if(detail.contains("Request key payload mismatch")||detail.contains("Reward payload mismatch"))throw new IllegalArgumentException("Yêu cầu cũ đã thay đổi. Tải lại rồi thực hiện thao tác mới.");if(detail.contains("Dungeon level or difficulty locked"))throw new IllegalArgumentException("Phó bản yêu cầu Lv 15 và vượt Thường trước khi vào Khó.");if(detail.contains("Item not owned"))throw new IllegalArgumentException("Chưa sở hữu vật phẩm.");if(detail.contains("PGRST202")&&detail.contains("gunny_checkout")||detail.contains("42703")&&detail.contains("wardrobe"))throw new IllegalStateException("Chạy migration shop 7.1.6 trên Supabase trước khi mua đồ.");if(detail.contains("user_already_exists")||detail.contains("email_exists")||detail.contains("User already registered"))throw new IllegalArgumentException("Tài khoản đã tồn tại. Hãy đăng nhập bằng mật khẩu cũ.");if(detail.contains("email_not_confirmed"))throw new IllegalArgumentException("Tài khoản cũ chưa được chuyển đổi. Liên hệ quản trị viên để giữ nguyên dữ liệu và kích hoạt đăng nhập.");if(detail.contains("Card already taken"))throw new IllegalArgumentException("Thẻ đã được mở. Chọn thẻ khác.");if(detail.contains("Insufficient earned coins"))throw new IllegalArgumentException("Chưa đủ xu để đổi.");if(detail.contains("Shopping wallet limit"))throw new IllegalArgumentException("Ví tiền mua sắm đã đầy.");if(detail.contains("Insufficient coins"))throw new IllegalArgumentException("Chưa đủ tiền mua sắm để mua đồ.");if(detail.contains("email_address_not_authorized")||detail.contains("Error sending confirmation"))throw new IllegalArgumentException("Dịch vụ tài khoản chưa sẵn sàng.");if(r.statusCode()==429)throw new IllegalArgumentException("Dịch vụ đang giới hạn yêu cầu. Thử lại sau.");if((r.statusCode()==400||r.statusCode()==401||r.statusCode()==422)&&path.startsWith("/auth/"))throw new IllegalArgumentException("Tên đăng nhập hoặc mật khẩu không đúng.");if(r.statusCode()==400&&path.startsWith("/rest/v1/rpc/"))throw new IllegalArgumentException("Không thể dùng vật phẩm lúc này. Hãy kiểm tra điều kiện và số lượng.");throw new IllegalStateException("Dịch vụ tài khoản tạm thời không phản hồi ("+r.statusCode()+").");}
        return r.body().isBlank()?null:Json.parse(r.body());
    }
    static String nameKey(String name){return java.text.Normalizer.normalize(name.trim(),java.text.Normalizer.Form.NFC).toLowerCase(Locale.ROOT);}
    void ensureNameAvailable(String name,String except)throws Exception{
        var input=new HashMap<String,Object>();input.put("p_name",name);input.put("p_except",except.isEmpty()?null:except);
        if(!Boolean.TRUE.equals(request("/rest/v1/rpc/gunny_name_available","POST",Json.write(input),true)))
            throw new IllegalArgumentException("Tên nhân vật đã được sử dụng. Hãy chọn tên khác.");
    }
    void register(String email,String password,String name)throws Exception{
        ensureNameAvailable(name,"");
        // Email is a login identifier only. No email is delivered or required to exist.
        Map<String,Object> r;
        try{r=Json.obj(request("/auth/v1/admin/users","POST",Json.write(Map.of("email",email,"password",password,"email_confirm",true,"user_metadata",Map.of("display_name",name),"app_metadata",Map.of("account_type","virtual"))),true));}catch(Exception error){ensureNameAvailable(name,"");throw error;}
        Object user=r.get("user");if(user instanceof Map)r=Json.obj(user);
        if(Json.str(r,"id").isEmpty())throw new IllegalStateException("Dịch vụ chưa tạo được tài khoản.");
    }
    void verifyEmail(String hash)throws Exception{Map<String,Object> r=Json.obj(request("/auth/v1/verify","POST",Json.write(Map.of("token_hash",hash,"type","email")),false));Map<String,Object> user=Json.obj(r.get("user"));if(user==null||Json.str(user,"email_confirmed_at").isEmpty())throw new IllegalArgumentException("Email chưa được xác nhận");}
    void verifyEmailAccess(String token)throws Exception{HttpRequest req=HttpRequest.newBuilder(URI.create(url+"/auth/v1/user")).timeout(Duration.ofSeconds(20)).header("apikey",key).header("Authorization","Bearer "+token).GET().build();HttpResponse<String> r=http.send(req,HttpResponse.BodyHandlers.ofString());if(r.statusCode()!=200)throw new IllegalArgumentException("Liên kết đã hết hạn; hãy đăng nhập");Map<String,Object> user=Json.obj(Json.parse(r.body()));if(Json.str(user,"email_confirmed_at").isEmpty())throw new IllegalArgumentException("Email chưa được xác nhận");}
    Login login(String email,String password)throws Exception{Map<String,Object> r=Json.obj(request("/auth/v1/token?grant_type=password","POST",Json.write(Map.of("email",email,"password",password)),false));Login l=new Login(Json.str(Json.obj(r.get("user")),"id"));l.lifetime=Math.min(3600,Json.num(r,"expires_in",3600));return l;}
    Profile profile(String id)throws Exception {
        UUID.fromString(id);List<?> rows=(List<?>)request("/rest/v1/profiles?id=eq."+id+"&select=*","GET",null,true);
        if(rows.isEmpty())throw new IllegalStateException("Chưa có hồ sơ. Hãy chạy migration Supabase.");Map<String,Object> r=Json.obj(rows.get(0));Profile p=new Profile(id,Json.str(r,"display_name"));p.publicId=Json.num(r,"public_id",0);p.gender=Json.num(r,"gender",0);p.skin=Json.num(r,"skin",0);p.coins=Json.num(r,"coins",0);p.wins=Json.num(r,"wins",0);p.experience=Json.num(r,"experience",0);p.owned=Json.num(r,"owned",1);p.equipped=Json.num(r,"equipped",0);p.characterChosen=!Boolean.FALSE.equals(r.get("character_chosen"));p.custom=Boolean.TRUE.equals(r.get("custom_look"));p.wornMask=Json.num(r,"worn_mask",p.custom?125:3);p.shoppingMoney=Json.num(r,"shopping_money",0);Object layout=r.get("bag_layout");if(layout instanceof List&&((List<?>)layout).size()==175)for(int i=0;i<175;i++)p.bagLayout[i]=((Number)((List<?>)layout).get(i)).intValue();Object look=r.get("look");if(look instanceof List)for(int i=0;i<5&&i<((List<?>)look).size();i++)p.look[i]=((Number)((List<?>)look).get(i)).intValue();Object wardrobe=r.get("wardrobe");if(wardrobe instanceof List)for(int i=0;i<12&&i<((List<?>)wardrobe).size();i++)p.wardrobe[i]=((Number)((List<?>)wardrobe).get(i)).intValue();p.stones=Json.num(r,"stones",0);p.dungeonClear=Boolean.TRUE.equals(r.get("dungeon_normal_clear"));Object forge=r.get("forge_levels");if(forge instanceof List){if(((List<?>)forge).size()!=130)throw new IllegalStateException("Sai dữ liệu cường hóa");for(int i=0;i<130;i++)p.forgeLevels[i]=Math.min(ForgeRules.MAX_RANK,((Number)((List<?>)forge).get(i)).intValue());}Object progress=r.get("forge_progress");if(progress instanceof List){if(((List<?>)progress).size()!=130)throw new IllegalStateException("Sai tiến độ cường hóa");for(int i=0;i<130;i++)p.forgeProgress[i]=((Number)((List<?>)progress).get(i)).intValue();}p.giftLevel=Json.num(r,"gift_level",1);p.giftBags=Json.num(r,"gift_bags",0);p.vipTickets=Json.num(r,"vip_tickets",0);if(r.get("vip_until") instanceof Number)p.vipUntil=((Number)r.get("vip_until")).longValue();p.testCheats=Boolean.TRUE.equals(r.get("test_cheats"));p.testGod=p.testCheats&&Boolean.TRUE.equals(r.get("test_god"));p.wings=Json.num(r,"wings",0);p.wingEquipped=Boolean.TRUE.equals(r.get("wing_equipped"));p.vipSpears=Json.num(r,"vip_spears",0);p.luckyCharms=Json.num(r,"lucky_charms",0);p.protectionCharms=Json.num(r,"protection_charms",0);
        Object material=r.get("craft_stones");if(material instanceof List && ((List<?>)material).size()==4)
            for(int i=0;i<4;i++)p.craftStones[i]=((Number)((List<?>)material).get(i)).intValue();
        p.maxDamage=Json.num(r,"max_damage",0);Object usages=r.get("weapon_uses");if(usages instanceof List&&((List<?>)usages).size()==10)for(int i=0;i<10;i++)p.weaponUses[i]=((Number)((List<?>)usages).get(i)).intValue();p.vipExp=Json.num(r,"vip_exp",0);p.wingOwned=Json.num(r,"vip_wings",0);p.equippedWing=Json.num(r,"vip_wing",p.wingEquipped?5:-1);
        Object cards=r.get("vip_cards");if(cards instanceof List&&((List<?>)cards).size()==13)for(int i=0;i<13;i++)p.vipCards[i]=((Number)((List<?>)cards).get(i)).intValue();
        return p;
    }
    /** Global leaderboard: stored profiles, not just logged-in sessions.
     * Read only the required public character fields with server credentials.
     * Exclude test accounts in Supabase before applying the protocol's 128-row cap.
     */
    List<Profile> rankingProfiles() throws Exception {
        String path="/rest/v1/profiles?select=id,public_id,display_name,experience,wins,max_damage,"
                +"equipped,weapon_uses,gender,skin,custom_look,worn_mask,look,test_cheats"
                +"&or=(test_cheats.eq.false,test_cheats.is.null)"
                +"&order=wins.desc,max_damage.desc,id.asc&limit=128";
        List<?> rows=(List<?>)request(path,"GET",null,true);
        List<Profile> result=new ArrayList<>(rows.size());
        for(Object item:rows){
            Map<String,Object> row=Json.obj(item);
            if(Boolean.TRUE.equals(row.get("test_cheats")))continue;
            Profile p=new Profile(Json.str(row,"id"),Json.str(row,"display_name"));
            p.publicId=Json.num(row,"public_id",0);
            p.experience=Json.num(row,"experience",0);
            p.wins=Json.num(row,"wins",0);
            p.maxDamage=Json.num(row,"max_damage",0);
            p.equipped=Json.num(row,"equipped",0);
            p.gender=Json.num(row,"gender",0);
            p.skin=Json.num(row,"skin",0);
            p.custom=Boolean.TRUE.equals(row.get("custom_look"));
            p.wornMask=Json.num(row,"worn_mask",p.custom?125:3);
            Object look=row.get("look");
            if(look instanceof List<?>)for(int i=0;i<5&&i<((List<?>)look).size();i++){
                Object v=((List<?>)look).get(i);if(v instanceof Number)p.look[i]=((Number)v).intValue();
            }
            Object uses=row.get("weapon_uses");
            if(uses instanceof List<?>)for(int i=0;i<10&&i<((List<?>)uses).size();i++){
                Object v=((List<?>)uses).get(i);if(v instanceof Number)p.weaponUses[i]=((Number)v).intValue();
            }
            result.add(p);
        }
        return result;
    }
    void recordStats(String match,List<Map<String,Object>> players)throws Exception{request("/rest/v1/rpc/gunny_stats793","POST",Json.write(Map.of("p_match",match,"p_players",players)),true);}
    Profile vip(String id,String op,int item,int quantity,String requestKey)throws Exception{
        request("/rest/v1/rpc/gunny_vip","POST",Json.write(Map.of("p_user",id,"p_op",op,"p_item",item,"p_quantity",quantity,"p_key",requestKey)),true);return profile(id);
    }
    Profile appearance(String id,String name,int gender,int skin,boolean custom,int[] look)throws Exception {UUID.fromString(id);request("/rest/v1/profiles?id=eq."+id,"PATCH",Json.write(Map.of("display_name",name,"gender",gender,"skin",skin,"custom_look",custom,"look",Arrays.stream(look).boxed().toList())),true);return profile(id);}
    int rank(String id)throws Exception{Map<String,Object> data=Json.obj(request("/rest/v1/rpc/gunny_progress","POST",Json.write(Map.of("p_user",id)),true));return Json.num(data,"rank",0);}
    Profile equip(String id,int kind,int item)throws Exception{request("/rest/v1/rpc/gunny_equip","POST",Json.write(Map.of("p_user",id,"p_kind",kind,"p_item",item)),true);return profile(id);}
    Profile bagLayout(String id,int[] slots)throws Exception{request("/rest/v1/rpc/gunny_bag_layout","POST",Json.write(Map.of("p_user",id,"p_layout",Arrays.stream(slots).boxed().toList())),true);return profile(id);}
    Profile exchange(String id,int amount,String key)throws Exception{request("/rest/v1/rpc/gunny_exchange","POST",Json.write(Map.of("p_user",id,"p_amount",amount,"p_key",key)),true);return profile(id);}
    Profile appearanceEquipped(String id,String name,int sex,int skin,boolean custom,int[] look,int mask)throws Exception{UUID.fromString(id);request("/rest/v1/profiles?id=eq."+id,"PATCH",Json.write(Map.of("display_name",name,"gender",sex,"skin",skin,"custom_look",custom,"look",Arrays.stream(look).boxed().toList(),"worn_mask",mask,"character_chosen",true)),true);return profile(id);}
    Profile checkout(String id,int sex,int[] cart)throws Exception{ShopCatalog.validate(cart);request("/rest/v1/rpc/gunny_checkout","POST",Json.write(Map.of("p_user",id,"p_sex",sex,"p_cart",Arrays.stream(cart).boxed().toList())),true);return profile(id);}
    Profile buy(String id,int weapon)throws Exception{request("/rest/v1/rpc/gunny_buy_weapon","POST",Json.write(Map.of("p_user",id,"p_weapon",weapon)),true);return profile(id);}
    void settle(String match,int winner,List<Map<String,Object>> players)throws Exception{settle(match,winner,players,0);}
    void settle(String match,int winner,List<Map<String,Object>> players,int kind)throws Exception{request("/rest/v1/rpc/gunny_finish_match","POST",Json.write(Map.of("p_match",match,"p_winner",winner,"p_players",players,"p_kind",kind)),true);}

    int[] claim(String match,String id,int card,int coins)throws Exception{Map<String,Object> r=Json.obj(request("/rest/v1/rpc/gunny_claim_card","POST",Json.write(Map.of("p_match",match,"p_user",id,"p_card",card,"p_coins",coins)),true));return new int[]{Json.num(r,"card",-1),Json.num(r,"coins",0)};}
    static void validateLayout(Profile p,int[] slots){if(slots.length!=175)throw new IllegalArgumentException("Sai túi");Set<String> seen=new HashSet<>();for(int pos=0;pos<175;pos++){int value=slots[pos];if(value==-1)continue;int kind=value/10,item=value%10,sex=pos<100?0:1;if(value<0||value>69||pos<25&&(kind!=0||!ShopCatalog.weapon(item)||(p.owned&(1<<item))==0)||pos>=25&&(kind<1||(p.wardrobe[sex*6+kind-1]&(1<<item))==0)||!seen.add((pos<25?"w":String.valueOf(sex))+":"+value))throw new IllegalArgumentException("Sai vị trí đồ");}}
    /** Explicit loopback-only test adapter; unavailable in a deployed Render service. */
    Profile economy780(String id,String operation,Map<String,Object> payload,String key)throws Exception{request("/rest/v1/rpc/gunny_economy780","POST",Json.write(Map.of("p_user",id,"p_operation",operation,"p_payload",payload,"p_key",key)),true);return profile(id);}
    Profile crafting(String id,String action,Map<String,Object> payload,String key,int roll)throws Exception{
        request("/rest/v1/rpc/gunny_crafting","POST",
            Json.write(Map.of("p_user",id,"p_action",action,"p_payload",payload,"p_key",key,"p_roll",roll)),true);
        return profile(id);
    }
    int[] claimDungeon(String match,String id,int pick,int card,int difficulty)throws Exception{Map<String,Object> r=Json.obj(request("/rest/v1/rpc/gunny_claim_dungeon_stones","POST",Json.write(Map.of("p_match",match,"p_user",id,"p_pick",pick,"p_card",card,"p_difficulty",difficulty)),true));return new int[]{Json.num(r,"card",-1),Json.num(r,"coins",0),Json.num(r,"stones",0),Json.num(r,"pick",-1),Json.num(r,"grade",1)};}
    int[] tribalDeck(String match)throws Exception{UUID.fromString(match);List<?> rows=(List<?>)request("/rest/v1/gunny_tribal_matches?id=eq."+match+"&select=deck","GET",null,true);List<?> values=(List<?>)Json.obj(rows.get(0)).get("deck");int[] deck=new int[18];for(int i=0;i<18;i++)deck[i]=((Number)values.get(i)).intValue();return deck;}
    int[] giftOpen(String id,int type,String key)throws Exception{Map<String,Object> r=Json.obj(request("/rest/v1/rpc/gunny_gift_open","POST",Json.write(Map.of("p_user",id,"p_type",type,"p_key",key)),true));List<?> rewards=(List<?>)r.get("rewards");int[] result=new int[rewards.size()*2];for(int i=0;i<rewards.size();i++){List<?> pair=(List<?>)rewards.get(i);result[i*2]=((Number)pair.get(0)).intValue();result[i*2+1]=((Number)pair.get(1)).intValue();}return result;}
    void testCheat(String id,int action,boolean enabled)throws Exception{request("/rest/v1/rpc/gunny_test_cheat","POST",Json.write(Map.of("p_user",id,"p_action",action,"p_enabled",enabled)),true);}
    Map<String,Object> tribal(String action,Map<String,Object> payload)throws Exception{return Json.obj(request("/rest/v1/rpc/gunny_tribal","POST",Json.write(Map.of("p_action",action,"p_payload",payload)),true));}
    int[] claim780(String match,String id,int pick,int card)throws Exception{Map<String,Object> r=Json.obj(request("/rest/v1/rpc/gunny_claim780","POST",Json.write(Map.of("p_match",match,"p_user",id,"p_pick",pick,"p_card",card)),true));return new int[]{Json.num(r,"card",-1),Json.num(r,"coins",0),Json.num(r,"stones",0),Json.num(r,"pick",-1)};}
    void finishAntStage(String match,int winner,List<Map<String,Object>> players,int difficulty)throws Exception{request("/rest/v1/rpc/gunny_finish_ant_stage","POST",Json.write(Map.of("p_match",match,"p_winner",winner,"p_players",players,"p_difficulty",difficulty)),true);}
    void finishDungeon780(String match,int winner,List<Map<String,Object>> players,int difficulty)throws Exception{request("/rest/v1/rpc/gunny_finish_dungeon780","POST",Json.write(Map.of("p_match",match,"p_winner",winner,"p_players",players,"p_difficulty",difficulty)),true);}
    static final class Memory extends CloudStore {
        int[] tribalDeck(String match){return ((int[])tribalStore.matches.get(match).get("deck")).clone();}
        final Map<String,int[]> giftReceipts=new HashMap<>();final Map<String,Integer> giftTypes=new HashMap<>();
        synchronized int[] giftOpen(String id,int type,String key){if(key.isEmpty()||key.length()>120)throw new IllegalArgumentException("Invalid gift key");String receipt=id+":"+key;if(giftReceipts.containsKey(receipt)){if(giftTypes.get(receipt)!=type)throw new IllegalArgumentException("Gift payload mismatch");return giftReceipts.get(receipt).clone();}Profile p=profile(id);int[] result;
         if(type==0){int lv=p.giftLevel;if(lv>70||Progression.level(p.experience)<lv)throw new IllegalArgumentException("Chưa đủ cấp mở hòm Lv "+lv);int stone=50+rewardRandom.nextInt(51),coin=100*lv;p.giftLevel++;p.stones=Math.min(999999,p.stones+stone);p.coins=Math.min(999999,p.coins+coin);result=lv<70?new int[]{0,p.giftLevel,1,coin,2,stone}:new int[]{1,coin,2,stone};}
         else if(type==1){if(p.giftBags<1)throw new IllegalArgumentException("Chưa có túi quà phó bản");p.giftBags--;int stone=20+rewardRandom.nextInt(51);p.craftStones[0]=Math.min(999999,p.craftStones[0]+stone);boolean vip=rewardRandom.nextInt(100)<10;if(vip)p.vipTickets=Math.min(999999,p.vipTickets+1);result=vip?new int[]{3,stone,4,1}:new int[]{3,stone};}
         else if(type==2){if(p.vipTickets<1)throw new IllegalArgumentException("Chưa có thẻ VIP");p.vipTickets--;p.vipUntil=Math.max(System.currentTimeMillis()/1000,p.vipUntil)+86400;result=new int[]{5,1};}
         else throw new IllegalArgumentException("Invalid gift");giftTypes.put(receipt,type);giftReceipts.put(receipt,result);return result.clone();}
        final Map<String,Integer> stoneGrades=new HashMap<>();
        synchronized int[] claimDungeon(String match,String id,int pick,int card,int difficulty){String key=match+":"+id+":"+pick;boolean legacy=rewards780.containsKey(key);int oldStones=profile(id).stones;int[] reward=claim780(match,id,pick,card);Integer grade=stoneGrades.get(key);if(grade==null){grade=legacy?1:StoneDrops.grade(difficulty,rewardRandom.nextInt(100));if(grade>1){Profile p=profile(id);p.stones=oldStones;p.craftStones[grade-2]=Math.min(999999,p.craftStones[grade-2]+reward[2]);}stoneGrades.put(key,grade);}return new int[]{reward[0],reward[1],reward[2],reward[3],grade};}
        final TribalMemory tribalStore=new TribalMemory(this);
        final Set<String> statReceipts=new HashSet<>();
        synchronized void recordStats(String match,List<Map<String,Object>> players){for(var row:players){String id=Json.str(row,"id");if(statReceipts.add(match+":"+id)){Profile p=profile(id);p.maxDamage=Math.max(p.maxDamage,Json.num(row,"damage",0));int w=Json.num(row,"weapon",p.equipped);if(w>=0&&w<10)p.weaponUses[w]++;}}}
        final Map<String,String> vipReceipts=new HashMap<>();
        synchronized Profile vip(String id,String op,int item,int quantity,String requestKey){
            Profile p=profile(id);String signature=id+":"+op+":"+item+":"+quantity;
            if(requestKey==null||!requestKey.matches("[A-Za-z0-9_-]{1,64}"))throw new IllegalArgumentException("Sai mã giao dịch VIP");
            if(vipReceipts.containsKey(requestKey)){if(!signature.equals(vipReceipts.get(requestKey)))throw new IllegalArgumentException("Mã giao dịch đã đổi nội dung");return p;}
            if(op.equals("use")){if(item<0||item>17||quantity!=1)throw new IllegalArgumentException("Sai vật phẩm quy đổi");if(item>=13){int grade=item-13,n=grade==0?p.stones:p.craftStones[grade-1],money=100*(1<<grade);if(n<1)throw new IllegalArgumentException("Chưa có đá cường hóa");if(p.shoppingMoney>999999-money)throw new IllegalArgumentException("Ví xu mua sắm đầy; chưa trừ vật phẩm");if(grade==0)p.stones--;else p.craftStones[grade-1]--;p.shoppingMoney+=money;}else{if(p.vipCards[item]<1)throw new IllegalArgumentException("Chưa có thẻ VIP");int gain=item==12?VipRules.TOTAL:(item+1)*100,room=Math.max(0,VipRules.TOTAL-p.vipExp),overflow=Math.max(0,gain-room);if(p.shoppingMoney>999999-overflow)throw new IllegalArgumentException("Ví xu mua sắm đầy; chưa trừ vật phẩm");p.vipCards[item]--;p.vipExp+=Math.min(room,gain);p.shoppingMoney+=overflow;}}
            else if(op.equals("buy")){if(item<0||item>4||quantity!=1||VipRules.level(p.vipExp)<VipRules.WING_VIP[item]||(p.wingOwned&(1<<item))!=0||p.shoppingMoney<VipRules.WING_PRICE[item])throw new IllegalArgumentException("Chưa đủ VIP/tiền hoặc đã sở hữu cánh");p.shoppingMoney-=VipRules.WING_PRICE[item];p.wingOwned|=1<<item;}
            else if(op.equals("equip")){if(quantity!=1||item< -1||item>5||item==5&&p.wings<1||item>=0&&item<5&&(p.wingOwned&(1<<item))==0)throw new IllegalArgumentException("Chưa sở hữu cánh");p.equippedWing=item;p.wingEquipped=item==5;}
            else if(op.equals("grant")){if(item<0||item>12||quantity<1||quantity>999999||p.vipCards[item]>999999-quantity)throw new IllegalArgumentException("Sai số thẻ VIP");p.vipCards[item]+=quantity;}
            else if(op.equals("cheats")){if(item!=0&&item!=1)throw new IllegalArgumentException("Sai trạng thái cheat");boolean enabled=item==1;if(enabled&&!p.testCheats)for(int i=0;i<13;i++)p.vipCards[i]=Math.min(999999,p.vipCards[i]+999);p.testCheats=enabled;if(!enabled)p.testGod=false;}
            else throw new IllegalArgumentException("Sai thao tác VIP");
            vipReceipts.put(requestKey,signature);return p;
        }
        synchronized void testCheat(String id,int action,boolean enabled){Profile p=profile(id);if(action==6){p.testCheats=enabled;if(!enabled)p.testGod=false;return;}if(!p.testCheats)throw new IllegalArgumentException("Cheat disabled");if(action==0){p.stones=999999;Arrays.fill(p.craftStones,999999);p.luckyCharms=p.protectionCharms=999999;}else if(action==1){for(int kind=0;kind<=6;kind++)for(int item=0;item<10;item++)if(ForgeRules.allowed(kind)&&(kind==0?(p.owned&(1<<item))!=0:(p.wardrobe[p.gender*6+kind-1]&(1<<item))!=0))p.forgeLevels[ForgeRules.index(p.gender,kind,item)]=15;}else if(action==2)p.experience=Progression.experienceForLevel(70);else if(action==3){p.shoppingMoney=p.coins=999999;}else if(action==4)p.testGod=enabled;else throw new IllegalArgumentException("Invalid cheat");}
        synchronized Map<String,Object> tribal(String action,Map<String,Object> payload){return tribalStore.apply(action,payload);}
        record Account(byte[] salt,byte[] hash,Profile profile){}
        final Map<String,Account> accounts=new ConcurrentHashMap<>();final Map<String,int[]> rewards=new ConcurrentHashMap<>();final Map<String,Set<String>> participants=new ConcurrentHashMap<>();final Set<String> settled=ConcurrentHashMap.newKeySet();final SecureRandom random=new SecureRandom();
        final boolean fresh;Memory(){this(false);}Memory(boolean clean){super(true);fresh=clean;}
        byte[] hash(String p,byte[] salt)throws Exception{PBEKeySpec spec=new PBEKeySpec(p.toCharArray(),salt,120000,256);try{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();}finally{spec.clearPassword();}}
        synchronized void ensureNameAvailable(String name,String except){for(var account:accounts.values())if(!account.profile.id.equals(except)&&nameKey(account.profile.name).equals(nameKey(name)))throw new IllegalArgumentException("Tên nhân vật đã được sử dụng. Hãy chọn tên khác.");}
        synchronized void register(String email,String password,String name)throws Exception{ensureNameAvailable(name,"");if(accounts.containsKey(email))throw new IllegalArgumentException("Email đã được dùng.");byte[] salt=new byte[16];random.nextBytes(salt);Profile p=new Profile(UUID.randomUUID().toString(),name);if(fresh){p.owned=p.wornMask=0;p.custom=true;Arrays.fill(p.wardrobe,0);}p.publicId=accounts.size()+1001;accounts.put(email,new Account(salt,hash(password,salt),p));}
        Login login(String email,String password)throws Exception{Account a=accounts.get(email);if(a==null||!MessageDigest.isEqual(a.hash,hash(password,a.salt)))throw new IllegalArgumentException("Sai email hoặc mật khẩu.");return new Login(a.profile.id);}
        Profile profile(String id){for(Account a:accounts.values())if(a.profile.id.equals(id))return a.profile;throw new IllegalArgumentException("Không có tài khoản.");}
        final Map<String,String> economyReceipts=new HashMap<>();final Map<String,int[]> rewards780=new HashMap<>();final Random rewardRandom=new Random();
        synchronized Profile economy780(String id,String operation,Map<String,Object> payload,String key){
            if(key==null||!key.matches("[A-Za-z0-9_-]{1,64}"))throw new IllegalArgumentException("Sai mã yêu cầu");String signature=id+":"+operation+":"+new TreeMap<>(payload);String prior=economyReceipts.get(key);
            if(prior!=null){if(!prior.equals(signature))throw new IllegalArgumentException("Request key payload mismatch");return profile(id);}Profile p=profile(id);
            if(operation.equals("buy")){int q=((Number)payload.get("quantity")).intValue();if(q<1||q>1000||p.shoppingMoney<q*80||p.stones>999999-q)throw new IllegalArgumentException("Chưa đủ tiền mua đá");p.shoppingMoney-=q*80;p.stones+=q;}
            else if(operation.equals("forge")){int sex=((Number)payload.get("sex")).intValue(),kind=((Number)payload.get("kind")).intValue(),item=((Number)payload.get("item")).intValue(),rank=((Number)payload.get("rank")).intValue(),progress=((Number)payload.get("progress")).intValue();if(!ForgeRules.allowed(kind))throw new IllegalArgumentException("Chỉ rèn vũ khí, áo, nón và kính");int i=ForgeRules.index(sex,kind,item);
                if(sex!=p.gender||kind==0&&(!ShopCatalog.weapon(item)||(p.owned&(1<<item))==0)||kind>0&&(p.wardrobe[sex*6+kind-1]&(1<<item))==0)throw new IllegalArgumentException("Chưa sở hữu trang bị");
                if(p.forgeLevels[i]!=rank||p.forgeProgress[i]!=progress)throw new IllegalArgumentException("Cấp rèn đã thay đổi");if(rank>=ForgeRules.MAX_RANK||p.stones<=0)throw new IllegalArgumentException("Chưa đủ đá cường hóa");int spend=Math.min(p.stones,ForgeRules.cost(rank)-progress);p.stones-=spend;p.forgeProgress[i]+=spend;if(p.forgeProgress[i]>=ForgeRules.cost(rank)){p.forgeProgress[i]=0;p.forgeLevels[i]++;}
            }else throw new IllegalArgumentException("Sai thao tác");economyReceipts.put(key,signature);return p;
        }
        synchronized Profile crafting(String id,String action,Map<String,Object> payload,String key,int roll){
            if(key==null||!key.matches("[A-Za-z0-9_-]{1,64}"))throw new IllegalArgumentException("Sai mã yêu cầu");
            String signature=id+":"+action+":"+new TreeMap<>(payload);
            String prior=economyReceipts.get("chance:"+key);
            if(prior!=null){if(!prior.equals(signature))throw new IllegalArgumentException("Request key payload mismatch");return profile(id);}
            Profile p=profile(id);
            int quantity=((Number)payload.get("quantity")).intValue();
            if(action.equals("buy")){
                int material=((Number)payload.get("material")).intValue();
                if(material<0||material>6||quantity<1||quantity>1000)throw new IllegalArgumentException("Sai vật liệu");
                int cost=ForgeRules.price(material)*quantity;
                int owned=material==0?p.stones:material<5?p.craftStones[material-1]:material==5?p.luckyCharms:p.protectionCharms;
                if(p.shoppingMoney<cost||owned>999999-quantity)throw new IllegalArgumentException("Chưa đủ tiền hoặc vượt giới hạn");
                p.shoppingMoney-=cost;
                if(material==0)p.stones+=quantity;else if(material<5)p.craftStones[material-1]+=quantity;
                else if(material==5)p.luckyCharms+=quantity;else p.protectionCharms+=quantity;
            }else if(action.equals("forge")){
                int sex=((Number)payload.get("sex")).intValue(),kind=((Number)payload.get("kind")).intValue(),
                    item=((Number)payload.get("item")).intValue(),rank=((Number)payload.get("rank")).intValue(),
                    grade=((Number)payload.get("grade")).intValue();
                boolean lucky=Boolean.TRUE.equals(payload.get("lucky")),protect=Boolean.TRUE.equals(payload.get("protect"));
                int chance=ForgeRules.chance(rank,grade,quantity,lucky);
                int index=ForgeRules.index(sex,kind,item);
                if(sex!=p.gender||!ForgeRules.allowed(kind)||chance==0||roll<0||roll>=10000
                    ||kind==0&&(!ShopCatalog.weapon(item)||(p.owned&(1<<item))==0)
                    ||kind>0&&(p.wardrobe[sex*6+kind-1]&(1<<item))==0)
                    throw new IllegalArgumentException("Sai trang bị");
                if(p.forgeLevels[index]!=rank)throw new IllegalArgumentException("Cấp rèn đã thay đổi");
                int stones=grade==1?p.stones:p.craftStones[grade-2];
                if(stones<quantity||lucky&&p.luckyCharms<1||protect&&p.protectionCharms<1)
                    throw new IllegalArgumentException("Thiếu đá hoặc bùa");
                if(grade==1)p.stones-=quantity;else p.craftStones[grade-2]-=quantity;
                if(lucky)p.luckyCharms--;if(protect)p.protectionCharms--;
                p.forgeLevels[index]=ForgeRules.result(rank,roll<chance,protect);
                p.forgeProgress[index]=0;
            }else throw new IllegalArgumentException("Sai thao tác");
            economyReceipts.put("chance:"+key,signature);
            return p;
        }
        synchronized int[] claim780(String match,String id,int pick,int card){int kind=matchKinds.getOrDefault(match,0);if((kind!=2&&kind!=3&&kind!=4)||pick<0||pick>(kind==4?0:1)||card<0||card>(kind==4?8:17)||!participants.getOrDefault(match,Set.of()).contains(id))throw new IllegalArgumentException("Không có quyền nhận thẻ");String key=match+":"+id+":"+pick;int[] old=rewards780.get(key);if(old!=null){if(old[0]!=card)throw new IllegalArgumentException("Reward payload mismatch");return old.clone();}
            if(pick==1&&!rewards780.containsKey(match+":"+id+":0"))throw new IllegalArgumentException("Chọn thẻ thứ nhất trước");for(var e:rewards780.entrySet())if(e.getKey().startsWith(match+":")&&e.getValue()[0]==card)throw new IllegalArgumentException("Thẻ đã được mở");int coins=0,stones=0;if(kind>=3)stones=10+rewardRandom.nextInt(91);else if(rewardRandom.nextBoolean())stones=1+rewardRandom.nextInt(10);else coins=500+rewardRandom.nextInt(1501);Profile p=profile(id);p.coins=Math.min(999999,p.coins+coins);p.stones=Math.min(999999,p.stones+stones);if(kind>=3){p.luckyCharms=Math.min(999999,p.luckyCharms+1);if(kind==3)p.protectionCharms=Math.min(999999,p.protectionCharms+1);}
            int[] r={card,coins,stones,pick};rewards780.put(key,r);return r.clone();}
        synchronized void finishAntStage(String match,int winner,List<Map<String,Object>> players,int difficulty){if(difficulty<0||difficulty>2||winner<0||winner>2||players.isEmpty()||players.size()>3)throw new IllegalArgumentException("Sai trận phó bản");if(settled.contains(match))return;Set<String> ids=new HashSet<>();for(var row:players){Profile p=profile((String)row.get("id"));if(!ids.add(p.id)||((Number)row.get("team")).intValue()!=0||Progression.level(p.experience)<15||difficulty==2&&!p.dungeonClear)throw new IllegalArgumentException("Chưa đủ điều kiện phó bản");}settled.add(match);matchKinds.put(match,4);participants.put(match,winner==0?ids:Set.of());for(String id:ids){Profile p=profile(id);p.experience=(int)Math.min(Integer.MAX_VALUE,p.experience+(winner==0?300L:100L));if(winner==0){p.wins++;}}}
        synchronized void finishDungeon780(String match,int winner,List<Map<String,Object>> players,int difficulty){if(difficulty<0||difficulty>2||winner<0||winner>2||players.isEmpty()||players.size()>3)throw new IllegalArgumentException("Sai trận phó bản");if(settled.contains(match))return;Set<String> ids=new HashSet<>();for(var row:players){Profile p=profile((String)row.get("id"));if(!ids.add(p.id)||((Number)row.get("team")).intValue()!=0||Progression.level(p.experience)<15||difficulty==2&&!p.dungeonClear)throw new IllegalArgumentException("Chưa đủ điều kiện phó bản");}settled.add(match);matchKinds.put(match,3);participants.put(match,winner==0?ids:Set.of());for(String id:ids){Profile p=profile(id);p.experience=(int)Math.min(Integer.MAX_VALUE,p.experience+(winner==0?300L:100L));if(winner==0){p.wins++;p.giftBags=Math.min(999999,p.giftBags+1);if(difficulty==1)p.dungeonClear=true;}}}
        synchronized Profile appearance(String id,String name,int gender,int skin,boolean custom,int[] look){ensureNameAvailable(name,id);Profile p=profile(id);p.name=name;p.gender=gender;p.skin=skin;p.custom=custom;p.wornMask=custom?125:3;p.look=look.clone();return p;}
        final Map<String,Integer> exchanges=new HashMap<>();
        synchronized Profile equip(String id,int kind,int item){Profile p=profile(id);if(kind<0||kind>6||item< -1||item>9)throw new IllegalArgumentException("Sai trang bị");if(item>=0){if(kind==0&&(!ShopCatalog.weapon(item)||(p.owned&(1<<item))==0)||kind>0&&(p.wardrobe[p.gender*6+kind-1]&(1<<item))==0)throw new IllegalArgumentException("Chưa sở hữu");if(kind==0)p.equipped=item;else if(kind==1)p.skin=item;else p.look[kind-2]=item;}p.wornMask=ItemRules.maskAfter(p.wornMask,kind,item<0);p.custom=(p.wornMask&2)==0;return p;}
        synchronized Profile bagLayout(String id,int[] slots){Profile p=profile(id);validateLayout(p,slots);p.bagLayout=slots.clone();return p;}
        synchronized Profile exchange(String id,int amount,String key){Profile p=profile(id);Integer prior=exchanges.get(id+":"+key);if(prior!=null){if(prior!=amount)throw new IllegalArgumentException("Sai mã đổi xu");return p;}if(amount<=0||amount>9999||p.coins/100<amount||p.shoppingMoney>999999-amount)throw new IllegalArgumentException("Không đủ xu hoặc số lượng không hợp lệ");p.coins-=amount*100;p.shoppingMoney+=amount;exchanges.put(id+":"+key,amount);return p;}
        synchronized Profile appearanceEquipped(String id,String name,int sex,int skin,boolean custom,int[] look,int mask){Profile p=appearance(id,name,sex,skin,custom,look);p.wornMask=mask;p.characterChosen=true;return p;}
        synchronized Profile checkout(String id,int sex,int[] cart){Profile p=profile(id);if(sex!=p.gender)throw new IllegalArgumentException("Sai nhân vật");int total=ShopCatalog.total(sex,cart,p.owned,p.wardrobe);if(p.shoppingMoney<total)throw new IllegalArgumentException("Chưa đủ tiền mua sắm");p.shoppingMoney-=total;p.owned|=cart[0];ShopCatalog.grant(sex,cart,p.wardrobe);return p;}
        synchronized Profile buy(String id,int weapon){Profile p=profile(id);int price=ShopCatalog.price(0,weapon);if((p.owned&(1<<weapon))==0){if(p.shoppingMoney<price)throw new IllegalArgumentException("Không đủ vàng.");p.shoppingMoney-=price;p.owned|=1<<weapon;}p.equipped=weapon;return p;}
        final Map<String,Integer> matchKinds=new HashMap<>();
        @Override synchronized List<Profile> rankingProfiles(){List<Profile> list=new ArrayList<>();for(Account a:accounts.values())if(!a.profile.testCheats)list.add(a.profile);return list;}
        int rank(String id){Profile p=profile(id);int higher=0;for(Account a:accounts.values())if(a.profile.wins>p.wins)higher++;return higher+1;}
        synchronized int[] claim(String match,String id,int card,int coins){int kind=matchKinds.getOrDefault(match,0);if(card<0||card>8||coins<(kind==2?500:200)||coins>(kind==2?2000:1000)||!participants.getOrDefault(match,Set.of()).contains(id))throw new IllegalArgumentException("Không có quyền nhận thưởng.");String key=match+":"+id;if(rewards.containsKey(key))return rewards.get(key).clone();for(Map.Entry<String,int[]> e:rewards.entrySet())if(e.getKey().startsWith(match+":")&&e.getValue()[0]==card)throw new IllegalArgumentException("Thẻ đã được mở. Chọn thẻ khác.");Profile p=profile(id);p.coins=Math.min(999999,p.coins+coins);int[] r={card,coins};rewards.put(key,r);return r.clone();}
        synchronized void settle(String match,int winner,List<Map<String,Object>> players){settle(match,winner,players,0);}
        synchronized void settle(String match,int winner,List<Map<String,Object>> players,int kind){if(kind<0||kind>2)throw new IllegalArgumentException("Sai loại trận");if(!settled.add(match))return;matchKinds.put(match,kind);Set<String> ids=new HashSet<>();for(Map<String,Object> p:players)if(Progression.reward(winner,((Number)p.get("team")).intValue(),((Number)p.getOrDefault("damage",0)).intValue()))ids.add((String)p.get("id"));participants.put(match,ids);for(Map<String,Object> player:players){Profile p=profile((String)player.get("id"));boolean won=((Number)player.get("team")).intValue()==winner;p.coins=Math.min(999999,p.coins+(won?(kind==2?1000:500):winner<2&&((Number)player.getOrDefault("damage",0)).intValue()>0?(kind==2?500:250):0));p.experience=(int)Math.min(2147483647L,p.experience+(won?300L:100L));if(won)p.wins++;}}
    }
}
